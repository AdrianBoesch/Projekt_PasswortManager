﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt_PasswortManager
{
    public class VerifPw
    {
        
            
            public string VerifPasswort { get; set; }
        
    }
}
